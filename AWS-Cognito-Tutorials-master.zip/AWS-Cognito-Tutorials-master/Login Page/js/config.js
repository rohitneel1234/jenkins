window._config = {
    cognito: {
        userPoolId: 'us-east-2_HkJ9bco1D', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-2', // e.g. us-east-2
		clientId: '4hedp5qc8clbc2vk5lo7ssiibm' //is this used anywhere?
    },
};

