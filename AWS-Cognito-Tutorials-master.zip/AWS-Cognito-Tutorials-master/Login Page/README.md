# AWS-Cognito-Tutorials
Code from Cognito Youtube Tutorials (Youtube: Nikhil Rao)

SDK's Needed
------------
  - https://sdk.amazonaws.com/js/aws-sdk-2.7.16.min.js
  - amazon-cognito-identity.min.js
  
 Other Resources
---------------
The full How-to can be found at https://docs.aws.amazon.com/cognito/latest/developerguide/tutorial-integrating-user-pools-javascript.html#tutorial-integrating-user-pools-user-sign-in-javascript











