window._config = {
    cognito: {
        userPoolId: 'us-east-1_5wSKSsjoO', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
		clientId: '3430o0nt4mstp8j40638p7gr5d' //is this used anywhere?
    },
};

