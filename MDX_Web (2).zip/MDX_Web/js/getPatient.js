$(document).ready(function() {

var emailId=localStorage.getItem("storage");

 var formData = {
           'EmailID' :emailId
        };
		var json = JSON.stringify(formData);
		//console.log(json);
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json,
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/getpatientsdata"
    }).then(function(data) {
		
		for(var i=0;i<data.HighAlerts;i++)
		{
			$('tbody').append('<tr class="high-alert"><td>'+
                                '<div class="round-img face-padding"><a href="#"><img class="rounded-circle" src="images/Faces/WOMAN40.png" alt=""></a></div>'+'</td><td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].MRNumber+'</td><td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].Name+'</td> <td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].Age+'</td><td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].PrimaryCondition+'</td><td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].SecondaryCondition+'</td><td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].TertiaryCondition+'</td><td>'+'<div class="extraPadding">'+data.HighAlertPatients[i].ConcerningSymptoms+'</td><td colspan="2">'+'<div class="extraPaddingLast"><div class="parent"><div class="switch_3_ways" style="background: #f7f7f7"><div id="low_1" class="switch low">L</div><div id="medium_1" class="switch medium" >M</div><div id="high_1" class="switch high active">H</div></div></div></div>'+'</td></tr>');

			if(data.HighAlertPatients[i].AlertStatus=="HIGH")
			{
				$('#high_1')				
			}	

			$('#low_1').click(function(){
			    change_period('low', 1);
			});
			$('#medium_1').click(function(){
			    change_period('medium', 1);
			});
			$('#high_1').click(function(){
			    change_period('high', 1);
			});
	
	  }
		for(var i=0;i<data.MediumAlerts;i++)
		{
			$('tbody').append('<tr class="medium-alert"><td>'+
                                '<div class="round-img face-padding"><a href="#"><img class="rounded-circle" src="images/Faces/WOMAN40.png" alt=""></a></div>'+'</td><td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].MRNumber+'</td><td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].Name+'</td> <td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].Age+'</td><td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].PrimaryCondition+'</td><td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].SecondaryCondition+'</td><td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].TertiaryCondition+'</td><td>'+'<div class="extraPadding">'+data.MediumAlertPatients[i].ConcerningSymptoms+'</td><td colspan="2">'+'<div class="extraPaddingLast"><div class="parent"><div class="switch_3_ways" style="background: #f7f7f7"><div id="low_2" class="switch low">L</div><div id="medium_2" class="switch medium active">M</div><div id="high_2" class="switch high">H</div></div></div></div>'+'</td></tr>');
		
			$('#low_2').click(function(){
			    change_period('low', 2);
			});
			$('#medium_2').click(function(){
			    change_period('medium', 2);
			});
			$('#high_2').click(function(){
			    change_period('high', 2);
			});
}
      for(var i=0;i<data.LowAlerts;i++)
		{
			$('tbody').append('<tr class="low-alert"><td>'+
                                '<div class="round-img face-padding"><a href="#"><img class="rounded-circle" src="images/Faces/WOMAN40.png" alt=""></a></div>'+'</td><td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].MRNumber+'</td><td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].Name+'</td> <td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].Age+'</td><td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].PrimaryCondition+'</td><td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].SecondaryCondition+'</td><td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].TertiaryCondition+'</td><td>'+'<div class="extraPadding">'+data.LowAlertPatients[i].ConcerningSymptoms+'</td><td colspan="2">'+'<div class="extraPaddingLast"><div class="parent"><div class="switch_3_ways" style="background: #f7f7f7"><div id="low_3" class="switch low active">L</div><div id="medium_3" class="switch medium">M</div><div id="high_3" class="switch high">H</div></div></div></div>'+'</td></tr>');

			$('#low_3').click(function(){
			    change_period('low', 3);
			});
			$('#medium_3').click(function(){
			    change_period('medium', 3);
			});
			$('#high_3').click(function(){
			    change_period('high', 3);
			});
									
		}
	
		
	  function change_period(period, id)
	  {
	  var low = document.getElementById("low_"+id);
	  var medium = document.getElementById("medium_"+id);
	  var high = document.getElementById("high_"+id);
	  if(period === "low"){
	    medium.className +=  "switch medium";
	    high.className +=  "switch high";
	    setTimeout(function(){
	      low.className +=  "switch low active";
	    },300);
	  }else if(period === "medium"){
	    low.className +=  "switch low";
	    high.className +=  "switch high";
	    setTimeout(function(){
	      medium.className +=  "switch medium active";
	    },300);
	  }else{
	    low.className +=  "switch low";
	    medium.className +=  "switch medium";
	    setTimeout(function(){
	      high.className +=  "switch high active";
	    },300);
	  }
	}
	  
var rating =[data.HighAlerts,data.MediumAlerts,data.LowAlerts]

var ratingBar = document.querySelectorAll(".js-rating-progress")

document.querySelector('#walk-score').innerHTML = rating[0]
document.querySelector('#transit-score').innerHTML = rating[1]
document.querySelector('#bike-score').innerHTML = rating[2]

document.querySelector('.walk-container .js-rating-progress').style.strokeDashoffset = 25 - rating[0]
document.querySelector('.transit-container .js-rating-progress').style.strokeDashoffset = 25 - rating[1]
document.querySelector('.bike-container .js-rating-progress').style.strokeDashoffset = 25 - rating[2]

for (i=0; i<ratingBar.length; i++) {
  if (rating[i] < 2) {
    ratingBar[i].classList.add('under-7')
  }
  if (6 < rating[i] && rating[i] <= 8) {
    ratingBar[i].classList.add('under-8')
  }
  if (10< rating[i]) {
    ratingBar[i].classList.add('under-10')
  }
}
	   //console.log(data.LowAlerts);
		   //$('#low_1').append(data.AllPatients[0].AlertStatus);
    });
});	
