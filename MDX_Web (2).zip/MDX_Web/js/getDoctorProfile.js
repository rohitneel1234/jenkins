$(document).ready(function() {
	$('form').submit(function(event) {

	var user_email=document.getElementById('usernm').value
	
	//console.log(user_email);
	 
	 var formData = {
            "EmailId":user_email
        };
		
		//document.getElementById('dname').innerHTML =user_email;
		localStorage.setItem("storage",user_email);
		var json = JSON.stringify(formData);
		//console.log(json);
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json,
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/getdoctorprofile"
    }).done(function(data) {
		console.log(data.FirstName);
       /*  $.post("", function (data) {
                    		//alert(data); // <-- add this code
                                    $("name").html(data.FirstName);
                             }); */
    });
    event.preventDefault();
	});
});
