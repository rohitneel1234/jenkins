$(document).ready(function() {

var dremail=localStorage.getItem("storage");

 var formData = {
            "EmailId":dremail
        };
		var json = JSON.stringify(formData);
		
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json,
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/getdoctorprofile"
    }).then(function(data) {
		console.log(data.FirstName)
       $('#dname').append('Dr.'+"&nbsp;"+data.FirstName+"&nbsp;"+data.LastName);
	    $('#speciality').append(data.Speciality);
    });
});
