#A Simple ECG Monitor for Android Platform

##What is this?

ECG Monitor is a simple ECG Wave displaying APP. After connecting to a Bluetooth ECG device, 
it allows your Android device to show and analysing the ECG data. 

**This project is under developing. If you have any question please email me:**
> Email: chickenjohn93@outlook.com