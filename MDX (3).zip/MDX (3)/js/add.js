$(document).ready(function() {
	
	$('form').submit(function(event) {

        // get the form data
        // there are many ways to get this data using jQuery (you can use the class or id also)
        var formData = {
            'FirstName' : $('input[name=personalnameRegister]').val(),
            'LastName' : $('input[name=lname]').val(),
			'EmailID'  : $('input[name=emailInputRegister]').val(),
			'Password'  : $('input[name=passwordInputRegister]').val(),
			'Phone'  : $('input[name=phone]').val(),
			'Gender'  : $('input[name=genders]').val(),
			'Hospital'  : $('input[name=pso]').val(),
			'Speciality'  : $('input[name=speciality]').val(),
			'PracticeCountry'  : $('input[name=country]').val(),
			'ZipCode'  : $('input[name=zip]').val(),
			'NpiNumber'  : $('input[name=npi]').val(),
			'MouthlabProviderID'  : $('input[name=mpid]').val(),
			'LicenseNumber'  : $('input[name=regnumber]').val(),
			'LicenseExpiry'  : new Date()
        };
	var json = JSON.stringify(formData);
	 console.log(json);
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json, 
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/registerdoctor"
    })
	  .done(function(data) {
       console.log(data.ReturnStatus);
    });
	// stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
	});
});
