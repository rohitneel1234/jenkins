/**
 * Author: Ravi Tamada
 * URL: www.androidhive.info
 * twitter: http://twitter.com/ravitamada
 */
package info.androidhive.loginandregistration.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request.Method;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.kosalgeek.asynctask.AsyncResponse;
import com.kosalgeek.asynctask.PostResponseAsyncTask;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import info.androidhive.loginandregistration.R;
import info.androidhive.loginandregistration.app.AppConfig;
import info.androidhive.loginandregistration.app.AppController;
import info.androidhive.loginandregistration.helper.SQLiteHandler;
import info.androidhive.loginandregistration.helper.SessionManager;

public class RegisterActivity extends Activity implements AsyncResponse {
    private static final String TAG = RegisterActivity.class.getSimpleName();
    private Button btnRegister;
    private Button btnLinkToLogin;
    private EditText inputFullName;
    private EditText inputEmail;
    private EditText inputPassword;
    private EditText inputMobile;
    private EditText inputcnpass;
    private ProgressDialog pDialog;
    private SessionManager session;
    private SQLiteHandler db;

    String upass,ucpass;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        inputFullName = (EditText) findViewById(R.id.name);
        inputEmail = (EditText) findViewById(R.id.email);
        inputPassword = (EditText) findViewById(R.id.password);
        inputcnpass=(EditText)findViewById(R.id.cnpassword);
        inputMobile = (EditText) findViewById(R.id.mobile);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnLinkToLogin = (Button) findViewById(R.id.btnLinkToLoginScreen);

        btnLinkToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputFullName.getText().toString().isEmpty()) {
                    inputFullName.setError("Enter name");
                    inputFullName.requestFocus();
                } else if (inputMobile.getText().toString().isEmpty()) {
                    inputMobile.setError("Enter Mobile Number");
                    inputMobile.requestFocus();
                } else if (inputPassword.getText().toString().isEmpty()) {
                    inputPassword.setError("Enter Password of atleast 6 characters");
                    inputPassword.requestFocus();

                } else {

                    upass = inputPassword.getText().toString();
                    ucpass = inputcnpass.getText().toString();

                    if ((upass.equals(ucpass)) == true) {

                        HashMap<String, String> postData = new HashMap<String, String>();
                        postData.put("uname", inputFullName.getText().toString());
                        postData.put("umobile", inputMobile.getText().toString());
                        postData.put("uemail", inputEmail.getText().toString());
                        postData.put("upass", inputPassword.getText().toString());

                        PostResponseAsyncTask loginTask =
                                new PostResponseAsyncTask(RegisterActivity.this, postData, RegisterActivity.this);
                        loginTask.execute("User-env.6pbpggm2wm.us-west-2.elasticbeanstalk.com/Registration.php");


                    }
                }
            }
        });

    }

    @Override
    public void processFinish(String s) {

            Toast.makeText(getApplicationContext(),"Account Created Successfully",Toast.LENGTH_SHORT).show();

            Intent i=new Intent(getApplicationContext(),MainActivity.class);

            startActivity(i);

    }
}

