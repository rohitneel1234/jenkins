package info.androidhive.loginandregistration.app;

public class AppConfig {
	// Server user login url
	public static String URL_LOGIN = "User-env.6pbpggm2wm.us-west-2.elasticbeanstalk.com/Login.php";

	// Server user register url
	public static String URL_REGISTER = "User-env.6pbpggm2wm.us-west-2.elasticbeanstalk.com/Registration.php";
}
