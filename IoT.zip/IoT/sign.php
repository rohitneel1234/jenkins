<?php

$strbtn =$_POST['login'];

if($strbtn == "Submit")
{
	$uname=$_POST['uname'];
	
	$upass=$_POST['upass'];
	
	$link = mysql_connect('localhost','root','');
	
	$conn = mysql_select_db('demo');
	
	$strquery="select * from signin where uname='$uname' and upass='$upass' ";
	
	$result = mysql_query($strquery) or die("Failed to query database".mysql_error());
	
	$row=mysql_fetch_array($result);		
	
	if($row['uname']==$uname && $row['upass']==$upass)
	{
		echo "login sucess";	
	}
	
	else
	{
		echo "failed to login";
	}
	
}

?>
