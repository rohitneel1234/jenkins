window._config={
	cognito:{
		userPoolId:'us-west-2_mZEM8Lxns',
		region:'us-west-2',
		clientId:'178qpq1atq0a4moerp2koq33tm',
		},
};
