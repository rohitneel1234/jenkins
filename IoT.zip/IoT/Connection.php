<?php
$servername = "localhost"; //replace it with c0havldscn4k name clu804isvyrp
$username = "root";  //replace it with your database username
$password = "";  //replace it with your database password
$dbname = "raspdb";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>