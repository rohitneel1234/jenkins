<?php

$strbtn =$_POST['register'];

if($strbtn == "Create")
{
	$uname=$_POST['uname'];
	
	$upass=$_POST['upass'];

	$mobile=$_POST['mobile'];
	
	$link = mysql_connect('localhost','root','');
	
	$conn = mysql_select_db('demo');
	
	$strQuery = "INSERT INTO signin (`uname`, `upass`, `mobile`) 
VALUES ('".$uname."','".$upass."', '".$mobile."');";
	$rs = mysql_query($strQuery);		
	
}

?>
