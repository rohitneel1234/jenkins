$(document).ready(function() {
	 var formData = {
            "EmailId":"rohitneel007@gmail.com"
        };
		var json = JSON.stringify(formData);
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json,
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/getdoctorprofile"
    }).then(function(data) {
		console.log(data.FirstName);
       $('span').append('Dr.'+data.FirstName+&nbsp;+data.LastName);
    });
});
