<?PHP
session_start();

if(isset($_POST['Log In'])=='login')
{
	$uname=$_POST['usernm'];
	
	echo $uname;
		
	$_SESSION['id']=$uname;

}
?>