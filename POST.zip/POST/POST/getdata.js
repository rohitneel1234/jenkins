$(document).ready(function() {
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data: {
          "EmailId":"mouthlab.one@gmail.com"
        },
        url:"https://df3uemce1e.execute-api.us-west-2.amazonaws.com/testing/getdoctors"
    }).then(function(data) {
       $('.first-name').append(data.Users[0].FirstName);
       $('.last-name').append(data.Users[0].LastName);
    });
});
