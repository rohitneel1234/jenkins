$(document).ready(function() {

	$('form').submit(function(event) {

	var islogged=false;

	var Username = localStorage.getItem("storage");

	console.log(Username);

	var userName = document.getElementById('usernm').value;

	console.log(userName);
    	
	//var userPass = document.getElementById('pass').value;
	
	//console.log(userPass);
	
	if(userName==Username)
	{
		localStorage.setItem("true",islogged);
		//alert("logged in");

	}

	else
	{
		alert("Error");
	}

     //     event.preventDefault();
	});
});
   
