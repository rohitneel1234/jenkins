window._config = {
    cognito: {
        userPoolId: 'us-west-2_mZEM8Lxns', // e.g. us-east-2_uXboG5pAb
        region: 'us-west-2', // e.g. us-east-2
		clientId: '178qpq1atq0a4moerp2koq33tm' //is this used anywhere?
    },
};

