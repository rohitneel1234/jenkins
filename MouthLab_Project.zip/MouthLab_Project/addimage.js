$(document).ready(function() {
	
	$('form').submit(function(event) {

        // get the form data
        // there are many ways to get this data using jQuery (you can use the class or id also)
        var formData = {
			'FirstName' : $('input[name=fname]').val(),
            'LastName' : $('input[name=lname]').val(),
            'Image' : $('input[name=response]').val()
        };
	var json = JSON.stringify(formData);
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json, 
        url:"https://df3uemce1e.execute-api.us-west-2.amazonaws.com/testing/adddoctor"
    })
	  .done(function(data) {
       console.log(data.ReturnStatus);
    });
	// stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
	});
});
