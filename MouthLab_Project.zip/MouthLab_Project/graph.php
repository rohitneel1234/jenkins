<?php
 
$dataPoints = array(
	array( "label" => "1 May"),
	array( "label" => "2 May"),
	array( "label" => "3 May"),
	array( "label" => "4 May"),
	array( "label" => "5 May"),
	array( "label" => "6 May"),
	array( "label" => "7 May")
);
 
?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	title: {
		text: "Push-ups Over a Week"
	},
	axisY: {
		title	: "Heart Rate",
		minimum: 60,
		maximum: 90,
		interval:5
	},
	data: [{
		type: "line",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html> 