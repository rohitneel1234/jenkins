$(document).ready(function() {

var dremail=localStorage.getItem("user_name");

 var formData = {
			"PatientEmailID":"mouthlab.two@gmail.com",
            "DoctorEmailID":dremail
        };
		var json = JSON.stringify(formData);
		
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json,
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/getpatientabout"
    }).then(function(data) {
		
		console.log(data.Weight);
		
		$('#ml').val($('#ml').val() +data.MLNumber);
	
		$('#dt').val($('#dt').val() +data.BirthDate);
		
		$('#width').val($('#width').val() +data.Weight);
				
		$('#height').val($('#height').val() +data.Height);
		
		$('#mr').val($('#mr').val() +data.MRNumber);
		
		$('#ssn').val($('#ssn').val() +data.Ssn);
    });
});
