$(document).ready(function() {
	
	$('form').submit(function(event) {
		
		var dremail=localStorage.getItem("user_name");
        
        var formData = {
      		'PatientEmailID':'mouthlab.two@gmail.com',
			'DoctorEmailID':dremail,
			'MLNumber': $('input[name=ml]').val(),
			'MRNumber' : $('input[name=mr]').val(),
			'Ssn' : $('input[name=ssn]').val()
        };
	var json = JSON.stringify(formData);
	
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json, 
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/savepatientabout"
    })
	  .done(function(data) {
       console.log(data.ReturnStatus);
    });
	// stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
	});
});
