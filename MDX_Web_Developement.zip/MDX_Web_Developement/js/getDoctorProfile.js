$(document).ready(function() {
	$('form').submit(function(event) {

	var user_email=document.getElementById('usernm').value
	
	//console.log(user_email);
	 
	 var formData = {
            "EmailId":user_email
        };
		
		localStorage.setItem("user_name",user_email);
		
		var json = JSON.stringify(formData);
		
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json,
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/getdoctorprofile"
    }).done(function(data) {
		console.log(data.FirstName);
    });
    event.preventDefault();
	});
});
