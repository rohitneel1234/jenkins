$(document).ready(function() {
	
	$('form').submit(function(event) {

		var today = new Date();
		var dd = today.getDate();

		var mm = today.getMonth()+1; 
		var yyyy = today.getFullYear();
		if(dd<10) 
		{
			dd='0'+dd;
		} 

		if(mm<10) 
		{
			mm='0'+mm;
		} 
		today = yyyy+'-'+mm+'-'+dd;
		
		console.log(today);
		
		var dremail=localStorage.getItem("storage");
        // get the form data
        // there are many ways to get this data using jQuery (you can use the class or id also)
        var formData = {
			'DoctorEmailID':dremail,
			'PatientEmailID'  : $('input[name=email]').val(),
			'PrimaryCondition' : $('input[name=pcond]').val(),
			'EnrollmentDate':today,
            'EnrollmentStatus':'testing',
			'ServiceType':'Face-to-Face'
        };
	var json = JSON.stringify(formData);
	 //console.log(json);
    $.ajax({
        type:"POST",
        dataType: "json",
        contentType:"application/json",
        data:json, 
        url:"https://jx6u7d3at5.execute-api.us-west-2.amazonaws.com/development/addpatient"
    })
	  .done(function(data) {
       console.log(data.ReturnStatus);
	   window.location.href = "home.html";
    });
	// stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
	});
});
